# DealHub AI Expert Prompt Library v2

This folder contains a coordinated team of expert prompts for Cursor.

## How to use
1. Put the `experts` folder in the root of your project.
2. Start most multi-domain requests with the Orchestrator.
3. Use the Review Pipeline for new features.
4. Keep `project_context.md` updated as your product evolves.

## Recommended entry points
- Multi-domain problem: `/experts/orchestrator.md`
- Need correct expert: `/experts/router.md`
- New feature planning: Product Manager + UX Designer + Architect
- Security concern: Security Auditor
- Launch readiness: Orchestrator using Product + Architect + Security + DevOps

## Team operating model
- Router chooses the right specialist(s)
- Orchestrator coordinates cross-functional work
- Review Pipeline enforces Plan -> Build -> Audit
