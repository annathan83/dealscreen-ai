# Project Context — DealHub AI

Project: DealHub AI

Purpose:
A mobile-first workspace for acquisition entrepreneurs and investors to organize deal information, notes, uploaded files, financials, contracts, and future AI-generated insights.

Target users:
- Acquisition entrepreneurs
- Search fund operators
- Private investors
- Small business buyers
- Consultants evaluating deals

Core stack:
- React Native with Expo
- Supabase (Postgres, Auth, Storage)
- Google Drive API integration
- OpenAI API integration (future + partial MVP support)

Core features:
- Deal dashboard
- Deal workspace
- Notes
- File upload
- Timeline / activity log
- Google Drive-backed deal folders
- Future AI document analysis

Business priorities:
- Fast MVP delivery
- Clean architecture
- Strong security
- Mobile-first UX
- Future paid subscription model

Security priority:
High. The app may store confidential financial, legal, and acquisition-related material.

Collaboration principle:
All experts should reference this file before making recommendations.
